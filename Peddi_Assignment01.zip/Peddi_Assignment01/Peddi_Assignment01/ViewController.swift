//
//  ViewController.swift
//  Peddi_Assignment01
//
//  Created by Peddi,Venkataramana on 1/28/23.
//

import UIKit

class ViewController: UIViewController {

    
   
    @IBOutlet weak var firstNameOutlet: UITextField!
    
  
    @IBOutlet weak var lastNameOutlet: UITextField!
    
  
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    
    @IBOutlet weak var details: UILabel!
    
    
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    @IBOutlet weak var agelabel: UILabel!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: Any) {
        
        var a = firstNameOutlet.text!
        var b = lastNameOutlet.text!
        
       details.text = "Details"
        fullNameLabel.text = "Full Name : \(a) \(b)"
       
        details.font = UIFont.boldSystemFont(ofSize: 30.0)
        var it = initialsLabel.text!
        initialsLabel.text = "Initials : \(b.prefix(1))\(a.prefix(1))"
        
        var ag = Int(yearOutlet.text!)
        var n = String(2023 - ag!)
        agelabel.text = "Age : \(n)"
       
        
    }
    @IBAction func ResetBTN(_ sender: Any) {
        details.text?.removeAll()
        fullNameLabel.text?.removeAll()
        initialsLabel.text?.removeAll()
        agelabel.text?.removeAll()
        
    }
   
    
   
    
    
    
}

