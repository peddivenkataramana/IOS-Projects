//
//  ViewController.swift
//  Student peddi
//
//  Created by Kamani,Venkata Keerthi on 4/11/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var sid: UITextField!
    
    var studn = stu()
    
    var isstudent  = false
    
    var studentsArray = students
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func get(_ sender: Any) {
        
        let a = sid.text!
        
        
        for student in studentsArray{
            if a == student.sid{
                //student found and store the student in a global variable.
                studn = student
                //boolean flag as true,since we found a student.
                isstudent = true
            }
        }
    }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                let transition = segue.identifier
                if transition == "result"{
                    //Create a destination of type studentInfoViewController
                    let destination = segue.destination as! aViewController
                    
                    //if student is exists in the array, we will assign the studentObj in the destination with "studentFound"
                    if isstudent {
                        destination.studentObj = studn
                    }else{
                        //if the given sid is not in the array, then the student is a guest!!
                        //we set the boolean in the destination as true!!
                        destination.guestUser = true
                    }
                    
                    
                }
            
        
    }
    
}

