//
//  ViewController.swift
//  Peddi_CalculatorApp
//
//  Created by Peddi,Venkataramana on 2/12/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var Displayoutlet: UILabel!
    
    
    var operand1:Double  = 0
    var _operator : Character = " "
    var operand2:Double = 0
    
      
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
         clearText()
    }

    @IBAction func zrbtn(_ sender: Any) {
//        Displayoutlet.text = "0"
//        if operand1 == -1.1 {
//            operand1 = 0
//        }
//        else{
//            operand2=0
//        }
        Displayoutlet.text! = Displayoutlet.text! + "0"
    }
    
    @IBAction func onebtn(_ sender: Any) {
        
//        Displayoutlet.text = "1"
//        if operand1 == -1.1 {
//            operand1 = 1
//        }
//        else{
//            operand2=1
//        }
  Displayoutlet.text! = Displayoutlet.text! + "1"
        
        
    }
   @IBAction func twobtn(_ sender: Any) {
//        Displayoutlet.text = "2"
//        if operand1 == -1.1 {
//            operand1 = 2
//        }
//        else{
//            operand2 = 2
//        }
     clearText()
    Displayoutlet.text! = Displayoutlet.text! + "2"
    
    }
    
    
    @IBAction func thrbtn(_ sender: Any) {
//        Displayoutlet.text = "3"
//        if operand1 == -1.1 {
//            operand1 = 3
//        }
//        else{
//            operand2=3
//        }
        Displayoutlet.text! = Displayoutlet.text! + "3"
    }
    
    @IBAction func furbtn(_ sender: Any) {
        //Displayoutlet.text = "4"
         
            Displayoutlet.text! =  (Displayoutlet.text!) + "4"
        
       // Displayoutlet.text = Displayoutlet.text! + "4"
    }
    
    
    @IBAction func fvoutlet(_ sender: Any) {
//        Displayoutlet.text = "5"
//        if operand1 == -1.1 {
//            operand1 = 5
//        }
//        else{
//            operand2=5
//        }
        Displayoutlet.text! = Displayoutlet.text! + "5"
        
    }
    
    @IBAction func sixbtn(_ sender: Any) {
//        Displayoutlet.text = "6"
//        if operand1 == -1.1 {
//            operand1 = 6
//        }
//        else{
//            operand2=6
//        }
        Displayoutlet.text! = Displayoutlet.text! + "6"
    }
    
    @IBAction func svnbtn(_ sender: Any) {
//        Displayoutlet.text = "7"
//        if operand1 == -1.1 {
//            operand1 = 7
//        }
//        else{
//            operand2=7
//        }
        Displayoutlet.text! = Displayoutlet.text! + "7"
    }
    
    @IBAction func egnbtn(_ sender: Any) {
//        Displayoutlet.text = "8"
//        if operand1 == -1.1 {
//            operand1 = 8
//        }
//        else{
//            operand2=8
//        }
        Displayoutlet.text! = Displayoutlet.text! + "8"
    }
    
    @IBAction func ninebtn(_ sender: Any) { //Displayoutlet.text = "9"
//        if operand1 == -1.1 {
//            operand1 = 9
//        }
//        else{
//            operand2=9
//        }
        
        Displayoutlet.text! = Displayoutlet.text! + "9"
         
    }
    
    @IBAction func mod(_ sender: Any) {
//
 
        _operator = "%"
                operand1 = Double(Displayoutlet.text!) ?? 0
        clearText()
        
    }
    
    @IBAction func plbtn(_ sender: Any) {
    
          _operator = "+"
           operand1 = Double(Displayoutlet.text!) ?? 0
           clearText()
        
    }
    
    
    
    

    @IBAction func minbtn(_ sender: Any) {
      
        _operator = "-"
                operand1 = Double(Displayoutlet.text!) ?? 0
        clearText()
    
    }
    
    @IBAction func mulbtn(_ sender: Any) {
//        Displayoutlet.text = "x"
         
        _operator = "x"
                operand1 = Double(Displayoutlet.text!)!
        clearText()
        }
    
    @IBAction func divbtn(_ sender: Any) {
 

        _operator = "÷"
                operand1 = Double(Displayoutlet.text!) ?? 0
           
        clearText()
        }
      
    @IBAction func eqbtn(_ sender: Any) {
        print("")
        operand2 = Double(Displayoutlet.text!) ?? 0
        
        //operand2 =
    
        
        if(_operator == "+"){
          print(operand1, operand2)
            Displayoutlet.text! = String(format : " %.f" ,operand1+operand2)
            
             
        }
        else if(_operator == "-"){
            
                      Displayoutlet.text! =  String(format : " %.f", operand1-operand2)
                  }
        
        else if(_operator == "x"){
              
                      Displayoutlet.text! =  String(format :"%.f",operand1*operand2)
                  }
        else if(_operator == "÷"){
            if(operand2 == 0){
                Displayoutlet.text!="Not a number"
            }else{
                var a = operand1/operand2
                Displayoutlet.text =  String(format :"%.5f",a)
            }}
        else if(_operator == "%"){
            Displayoutlet.text! =  String(format :"%.1f",operand1.truncatingRemainder(dividingBy:operand2))
            //Displayoutlet.text = "\(operand1.truncatingRemainder(dividingBy: operand2))"
                  }
        
      
       
  
    
    }
    
    @IBAction func Acbtn(_ sender: Any) {
      //  operand1
     
       
        operand2 = 0
        operand1=0
//        _operator = " "
        Displayoutlet.text! = ""
    }
 
    @IBAction func plumibtn(_ sender: Any) {
          
        Displayoutlet.text! = "-" + Displayoutlet.text!
        
    }

    @IBAction func dtbtn(_ sender: Any) {
        
        Displayoutlet.text! =  Displayoutlet.text!+"."
    }
    func clearText() {
        Displayoutlet.text!.removeAll()
 
        }
    
    @IBAction func clbtn(_ sender: Any) {
        if(!_operator.description.isEmpty){
             
            Displayoutlet.text?.removeLast()
        }
//        Displayoutlet.text! =   "\(String(describing: Displayoutlet.text?.removeLast()))"
//
    }
    
}
    

