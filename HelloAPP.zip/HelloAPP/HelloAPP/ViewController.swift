//
//  ViewController.swift
//  HelloAPP
//
//  Created by Peddi,Venkataramana on 1/24/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameinputoutlet: UITextField!
    
    @IBOutlet weak var Displaylabeloutlets: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func UIButton(_ sender: Any) {
        // read the input and (assign it to a variable.)
        var input = nameinputoutlet.text!
        //Perform String interpolation "Hello, name!" and assign it to display label
        Displaylabeloutlets.text="Hello,\(input)!"
    }
}

