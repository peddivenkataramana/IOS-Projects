//
//  MovieCollectionViewCellCollection.swift
//  Peddi_Movies
//
//  Created by Peddi,Venkataramana on 4/24/23.
//

import UIKit

class MovieCollectionViewCellCollection: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    
    func assignMovie(with movie: Movie){
            image.image = movie.image
        }
    
}
