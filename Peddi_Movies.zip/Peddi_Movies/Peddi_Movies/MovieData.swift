//
//  MovieData.swift
//  Peddi_Movies
//
//  Created by Peddi,Venkataramana on 4/24/23.
//

import Foundation
import UIKit

struct Movie{
    
    var   title:String
    var image:UIImage!
    var releasedYear:String
    var movieRating:String
    var  boxOffice:String
    var  moviePlot:String
    var   cast:[String]
    
}
struct Genre{
    var category:String
    var movies:[Movie]
}

let a = Genre(category: "Action", movies:[
   Movie(title: "Gladiator", image: UIImage(named:"gla")!, releasedYear: "2000", movieRating: "8.5", boxOffice: "503.2M", moviePlot: "It traces Maximus fall from his prestigious career as a Roman general, to his enslavement, to his eventual resurrection as the premier gladiator in Rome.", cast:[" Russell Crowe" ,"Joaquin Phoenix", "Connie Nielsen"]),

Movie(title: "Terminator 2", image:UIImage(named: "ter")!, releasedYear: "1991", movieRating: "8.6", boxOffice: "520.9M", moviePlot: "echnology itself is amoral and it is how it gets used that gives it a morality. Terminator is essentially a gun, who can be either used to destroy or to protect.", cast: ["Arnold Schwarzenegger","Linda Hamilton"]),

Movie(title: "Star Wars", image: UIImage(named: "star")!, releasedYear: "1980", movieRating: "8.7", boxOffice: "538M", moviePlot: "uke Skywalker joins forces with a Jedi Knight, a cocky pilot, a Wookiee and two droids to save the galaxy from the Empire's world-destroying battle station, while also attempting to rescue Princess Leia from the mysterious Darth Vader.", cast: ["Mark Hamill","Harrison Ford "]),

Movie(title: "The Matrix", image: UIImage(named: "mat")!, releasedYear: "1999", movieRating: "8.7", boxOffice: "467M", moviePlot: "Neo (Keanu Reeves) believes that Morpheus (Laurence Fishburne), an elusive figure considered to be the most dangerous man alive, can answer his question -- What is the Matrix? Neo is contacted by Trinity (Carrie-Anne Moss), a beautiful stranger who leads him into an underworld where he meets Morpheus.", cast: ["Keanu Reeves","Laurence Fishburne"]),

Movie(title: "Inception", image:UIImage(named: "in")!, releasedYear: "2010", movieRating: "8.8", boxOffice: "836.8M", moviePlot: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project and his team to disaster.", cast: ["Leonardo DiCaprio","Joseph Gordon-Levitt"])
])


let b = Genre(category: "Horror", movies: [
    
Movie(title: "THE CONJURING", image: UIImage(named: "con")!, releasedYear: "2013", movieRating: "7.6", boxOffice: "319.5M", moviePlot: "In 1971, Roger and Carolyn Perron move into a farmhouse in Harrisville, Rhode Island, with their five daughters: Andrea, Nancy, Christine, Cindy, and April. Their dog, Sadie, refuses to enter the house and the entrance to a cellar has been boarded up. Paranormal events occur within the first few nights.", cast: ["Vera Farmiga","Mackenzie Foy"]),
    
Movie(title: "IT", image:UIImage(named: "it")!, releasedYear: "2017", movieRating: "7.3", boxOffice: "701.8M", moviePlot: "When young children in the little town Derry, Maine goes missing a group of seven kids find out that the killer is not a man.", cast: ["Jaeden Lieberher","Bill Skarsgård "]),
                                          
                                          
Movie(title: "OUIJA", image:UIImage(named:  "ou")!, releasedYear: "2016", movieRating: "4.5", boxOffice: "81.7M", moviePlot: "While this film teases its viewer with some slightly eerie moments and sudden scares, the majority fall flat and cheap. Ouija commits the crime of taking itself too seriously while also being an incredible bore. July 18, 2022 | Rating: 0/4 | Full Review… The planchette (the ouija's triangular pointer) is aimed at No.", cast: ["Olivia Cooke","Ana Coto"]),
                                          
Movie(title: "SCREAM 4", image: UIImage(named: "scr")!, releasedYear: "2011", movieRating: "6.3", boxOffice: "97.2M", moviePlot :"The film takes place on the fifteenth anniversary of the original Woodsboro murders from Scream (1996) and involves Sidney Prescott (Campbell) returning to the town after ten years, where Ghostface once again begins killing students from Woodsboro High.", cast:["David Arquette","Neve Campbell" ]),
                                          
Movie(title: "UNFRIENDED", image:UIImage(named: "unfrd")!, releasedYear: "2014", movieRating: "5.6", boxOffice: "62.9M", moviePlot: "The film stars Shelley Hennig, Moses Storm, Renee Olstead, Will Peltz, Jacob Wysocki, and Courtney Halverson as six high school students in a Skype conversation which is haunted by a student, played by Heather Sossaman, who was bullied by them and committed suicide.", cast: ["Shelley Hennig ","Moses Storm "])
                                          ])
 
let c = Genre(category: "Adventure", movies: [
    Movie(title: "WALL-E", image: UIImage(named: "wall")!, releasedYear: "2008", movieRating: "8.4", boxOffice: "532.5M", moviePlot: "Image result for wall-e box mainplot.The overall ninth feature film produced by the studio, WALL-E follows a solitary robot on a future, uninhabitable, deserted Earth in 2805, left to clean up garbage.", cast: ["Ben Burtt","Jeff Garlin"]),

Movie(title: "Coco", image: UIImage(named: "coco")!, releasedYear: "2017", movieRating: "8.4", boxOffice: "814.3M", moviePlot: "The story follows a 12-year-old boy named Miguel (Gonzalez) who is accidentally transported to the Land of the Dead, where he seeks the help of his deceased musician great-great-grandfather to return him to his family among the living and to reverse his family's ban on music.", cast: ["Anthony Gonzalez ","Benjamin Bratt "]),

Movie(title: "Aliens", image: UIImage(named: "alien")!, releasedYear: "1986", movieRating: "8.4", boxOffice: "184.7M", moviePlot: "Decades after surviving the Nostromo incident, Ellen Ripley is sent out to re-establish contact with a terraforming colony but finds herself battling the Alien Queen and her offspring.", cast: ["Sigourney Weaver","Michael Biehn "]),

Movie(title: "Spider-Man", image: UIImage(named: "spi")!, releasedYear:"2018", movieRating: "8.4", boxOffice: "384.3M", moviePlot: "Teen Miles Morales becomes the Spider-Man of his universe, and must join with five spider-powered individuals from other dimensions to stop a threat for all realities.", cast: ["Shameik Moore","Jake Johnson "]),

    Movie(title: "Avengers Endgame", image: UIImage(named: "aver")!, releasedYear:"2019", movieRating: "8.4", boxOffice: "2.7B", moviePlot: "The overwhelming devastation caused by the mad Titan Thanos has left what remains of the Avengers reeling. For a while, all hope seems lost... until an opportunity to reverse the damage is presented. Now, the team must assemble once more and do whatever it takes to restore the universe and bring those they lost back.", cast: ["Robert Downey Jr","Chris Evans"])
])



let array = [a,b,c]
