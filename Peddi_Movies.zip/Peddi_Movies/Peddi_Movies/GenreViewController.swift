//
//  GenreViewController.swift
//  Peddi_Movies
//
//  Created by Peddi,Venkataramana on 4/24/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return obj.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier:  "sectionCell", for: indexPath)
                
                //populate a cell
                cell.textLabel?.text = obj[indexPath.row].category
                
                //return a cell
                return cell
    }
    
    var obj = array
    
   
    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        genreTableView.dataSource = self
        genreTableView.delegate = self
        title.self = "Movies App"
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "movieSegue"{
                let destination = segue.destination as! MoviesViewController
                
                destination.objarr = obj[(genreTableView.indexPathForSelectedRow?.row)!]
            }
        }
    
    

}


