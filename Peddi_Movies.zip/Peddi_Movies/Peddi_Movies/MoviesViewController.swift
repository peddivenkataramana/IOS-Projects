//
//  MoviesViewController.swift
//  Peddi_Movies
//
//  Created by Peddi,Venkataramana on 4/24/23.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDataSource  , UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        objarr!.movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCellCollection
                
        cell.assignMovie(with: objarr!.movies[indexPath.row])
                
                return cell
    }
   

    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    var objarr:Genre?
    
    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDetails(index: indexPath)
    }
    
    func assignMovieDetails(index: IndexPath){
        movieNameLabel.text = "Movie title: \(objarr!.movies[index.row].title)"
        movieRatingLabel.text = "Movie Rating:\(objarr!.movies[index.row].movieRating)"
        movieBoxOfficeLabel.text = "Box Office Collection:\(objarr!.movies[index.row].boxOffice)"
        moviePlotLabel.text = "Plot:\n\(objarr!.movies[index.row].moviePlot)"
        movieCastLabel.text = "Cast:\n \(objarr!.movies[index.row].cast[0]),\(objarr!.movies[index.row].cast[0])"
//        for element in objarr!.movies[index.row].cast {
//            movieCastLabel.text = "\(element),"
//        }

        movieYearLabel.text = "Movie Release Year:\(objarr!.movies[index.row].releasedYear)"
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
         
        movieCollectionView.dataSource = self
        movieCollectionView.delegate = self
        
        
        title.self = objarr?.category
        
    }
    
    
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


