//
//  Universities.swift
//  Peddi_UniversityApp
//
//  Created by Peddi,Venkataramana on 4/18/23.
//

import Foundation

struct Universities{
    
   var domains = ""
    var list_Array:[UniversityList] = []
    
}

struct UniversityList{
    var collegeName = ""
    var collegeImage = ""
    var collegeInfo = ""
}
 

 



let uni1 = Universities(domains:"Computer Science" , list_Array:[
    UniversityList(collegeName:"Arizona State University",collegeImage:"arizona",collegeInfo:"Arizona State University (Arizona State or ASU) is a public research university[10] in the Phoenix metropolitan area.[11] Founded in 1885 by the 13th Arizona Territorial Legislature, ASU is one of the largest public universities by enrollment in the United States."),
    UniversityList(collegeName:"Stanford University",collegeImage:"stanford",collegeInfo:"Stanford University, officially Leland Stanford Junior University, is a private research university in Stanford, California. The campus occupies 8,180 acres, among the largest in the United States, and enrolls over 17,000 students."),
    UniversityList(collegeName:"University of California--Berkeley",collegeImage:"cafi",collegeInfo:"The University of California, Berkeley (UC Berkeley, Berkeley, Cal, or California)[11][12] is a public land-grant research university in Berkeley, California. Established in 1868 as the University of California, it is the state's first land-grant university and the founding campus of the University of California system."),

    UniversityList(collegeName:"University of Illinois--Urbana-Champaign",collegeImage:"illi",collegeInfo:"The University of Illinois Urbana-Champaign is a public land-grant research university in Illinois in the twin cities of Champaign and Urbana. It is the flagship institution of the University of Illinois system and was founded in 1867."),
    UniversityList(collegeName:"Massachusetts Institute of Technology",collegeImage:"massu",collegeInfo:"The Massachusetts Institute of Technology is a private land-grant research university in Cambridge, Massachusetts. Established in 1861, MIT has played a significant role in the development of many areas of modern technology and science.")])
    
     
 


let uni2 = Universities(domains:"Electrical Engineering" , list_Array:[UniversityList(collegeName:"Johns Hopkins University",collegeImage:"john",collegeInfo:"Johns Hopkins University is a private research university in Baltimore, Maryland. Founded in 1876, Johns Hopkins was the first U.S. university based on the European research institution model. It consistently ranks among the most"),
                                                                      
    UniversityList(collegeName:"Carnegie Mellon University",collegeImage:"CMU",collegeInfo:"Carnegie Mellon University is a private research university in Pittsburgh, Pennsylvania. The institution was originally established in 1900 by Andrew Carnegie as the Carnegie Technical Schools. In 1912, it became the Carnegie Institute of Technology and began granting four-year degrees."),
 UniversityList(collegeName:"Cornell University",collegeImage:"cornell",collegeInfo:"Cornell University is a private Ivy League statutory land-grant research university based in Ithaca, New York. The university was founded in 1865 by Ezra Cornell and Andrew Dickson White with the intention of teaching and making contributions in all fields of knowledge from the classics to the sciences and from the theoretical to the applied.[8]"),
    UniversityList(collegeName:"Duke University",collegeImage:"duke",collegeInfo:"Duke University is a private research university in Durham, North Carolina. Founded by Methodists and Quakers in the present-day city of Trinity in 1838, the school moved to Durham in 1892."),
UniversityList(collegeName:"Washington University in St Louis",collegeImage:"wash",collegeInfo:"Washington University in St. Louis (WashU, WUSTL or Washington University) is a private research university with its main campus in St. Louis County, and Clayton, Missouri. Founded in 1853, the university is named after George Washington.[8]")])
 
 

let uni3 = Universities(domains:"Biomedical Engineering" , list_Array:[UniversityList(collegeName:"Rice University",collegeImage:"rice",collegeInfo:"William Marsh Rice University, known simply as Rice University, is a private research university in Houston, Texas. It is on a 300-acre campus near the Houston Museum District and adjacent to the Texas Medical Center. "),
UniversityList(collegeName:"Georgia Institute of Technology",collegeImage:"geo",collegeInfo:"The Georgia Institute of Technology, commonly referred to as Georgia Tech or, in the state of Georgia, as Tech or The Institute, is a public research university and institute of technology in Atlanta, Georgia."),
    UniversityList(collegeName:"University of Pennsylvania",collegeImage:"pen",collegeInfo:"The University of Pennsylvania, often abbreviated simply as Penn or UPenn,[12][13] is a private Ivy League research university in Philadelphia. It was one of nine colonial colleges chartered prior to the U.S. Declaration of Independence when Benjamin Franklin, the university's founder and first president, advocated for an educational institution that trained leaders in academia, commerce, and public service."),
    UniversityList(collegeName:"University of Michigan",collegeImage:"mich",collegeInfo:"The University of Michigan (U-M, UMich, or Michigan) is a public research university in Ann Arbor, Michigan. Founded in 1817 as the Catholepistemiad, or the School of Universal Knowledge, the university is the oldest in Michigan; it was established 20 years before the territory became a state. The University of Michigan is ranked among the top universities in the world."),
                                                                      
UniversityList(collegeName:"Boston University",collegeImage:"bos",collegeInfo:"Boston University is a private research university in Boston, Massachusetts. BU was founded in 1839 by a group of Boston Methodists with its original campus in Newbury, Vermont, before being chartered in Boston in 1869.")
                                                                      ])

 


let uni4 = Universities(domains:"Computer and Information Networks" , list_Array:[
    UniversityList(collegeName:"New York University",collegeImage:"ny",collegeInfo:"New York University (NYU) is a private research university in New York City. Chartered in 1831 by the New York State Legislature,[14] NYU was founded by a group of New Yorkers led by then-Secretary of the Treasury Albert Gallatin.In 1832, the non-denominational all-male institution began its first classes near City Hall based on a curriculum focused on a secular education."),
                                                                                 
    UniversityList(collegeName:"University of Minnesota",collegeImage:"min",collegeInfo:"The University of Minnesota, formally the University of Minnesota, Twin Cities, is a public land-grant research university in the Twin Cities of Minneapolis and Saint Paul, Minnesota, United States."),
    UniversityList(collegeName:"Rochester Institute of Technology",collegeImage:"rit",collegeInfo:"Rochester Institute of Technology is a private research university in the town of Henrietta in the Rochester, New York, metropolitan area. The university was founded in 1829 and is the tenth largest private university in the United States in terms of full-time students."),
                                                                                 
UniversityList(collegeName:"DePaul University",collegeImage:"de",collegeInfo:"DePaul University is a private Catholic research university in Chicago, Illinois. Founded by the Vincentians in 1898, the university takes its name from the 17th-century French priest Saint Vincent de Paul. In 1998, it became the largest Catholic university in terms of enrollment in North America. Following in the footsteps of its founders, DePaul places special emphasis on recruiting first-generation students and others from disadvantaged backgrounds."),
UniversityList(collegeName:"Ohio University",collegeImage:"oh",collegeInfo:"Ohio University is a public research university in Athens, Ohio.[7] The first university chartered by an Act of Congress[8] and the first to be chartered in Ohio,[9] the university was chartered in 1787 by the Congress of the Confederation and subsequently approved for the territory in 1802 and state in 1804,[10] opening for students in 1809.[11] Ohio University is the oldest university in Ohio and among the oldest public universities in the United States.")])

 



let universitiesList:[Universities] = [uni1,uni2,uni3,uni4]



