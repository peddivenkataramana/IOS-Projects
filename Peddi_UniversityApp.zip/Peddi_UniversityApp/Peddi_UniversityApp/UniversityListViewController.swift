//
//  UniversityListViewController.swift
//  Peddi_UniversityApp
//
//  Created by Peddi,Venkataramana on 4/18/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return obj.list_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier:  "listCell", for: indexPath)

                //populate a cell
        cell.textLabel?.text = obj.list_Array[indexPath.row].collegeName

                //return a cell
                return cell
         
    }
    
    
    
    
    
    
    var obj = Universities()

    @IBOutlet weak var universityListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
        // Do any additional setup after loading the view.
        self.title = obj.domains
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "universityInfoSegue"{
                let destination = segue.destination as! UniversityInfoViewController
                
                destination.data = obj.list_Array[(universityListTableView.indexPathForSelectedRow?.row)!]
            }

}
}
