//
//  UniversitiesViewController.swift
//  Peddi_UniversityApp
//
//  Created by Peddi,Venkataramana on 4/18/23.
//

import UIKit

class UniversitiesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return uni.count    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier:  "domainCell", for: indexPath)

                //populate a cell
                cell.textLabel?.text = uni[indexPath.row].domains

                //return a cell
                return cell
    }
    var uni = universitiesList

    @IBOutlet weak var universitiesTableView: UITableView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        // Do any additional setup after loading the view.
        self.title = "Domains"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "listsSegue"{
                let destination = segue.destination as! UniversityListViewController
                
                destination.obj = uni[(universitiesTableView.indexPathForSelectedRow?.row)!] 
            }
        }



  

}
