//
//  UniversityInfoViewController.swift
//  Peddi_UniversityApp
//
//  Created by Peddi,Venkataramana on 4/18/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {

    var data = UniversityList()
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         
        self.title = data.collegeName

        UIView.animate(withDuration: 0.7, animations: {
                       
                       self.universityImageViewOutlet.center.x = self.view.center.y - 770
                       
           
                      
            })
        universityImageViewOutlet.image = UIImage(named:data.collegeImage)
//        universityImageViewOutlet.image = UIImage(named: data.collegeImage)
        
    }
   
    @IBAction func showInfoAction(_ sender: Any) {
        
       
        universityInfoOutlet.text = data.collegeInfo
         
        
        
        
    }
    
    
    
    
    
    
        }
    
    
    
    
    
 
