//
//  ViewController.swift
//  vowels
//
//  Created by Peddi,Venkataramana on 1/31/23.
//

import UIKit



class ViewController: UIViewController {
    
    
    @IBOutlet weak var textoutlet: UITextField!
    
    
    
    @IBOutlet weak var displaylabel: UILabel!
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitbtn(_ sender: Any) {
        
        var a = textoutlet.text!
       
            
                if(a.contains("a"))
        {
                    displaylabel.text = "a"
                    
                }
          if (a.contains("e"))
                 {
            displaylabel.text = "e"
            
        }
                   if (a.contains("i"))
                 {
            displaylabel.text = "i"
        }
          if(a.contains("o"))
        {
            displaylabel.text = "u"
        }
      
                    
                   
    }
                   
                   
                   
                   
                   
                   
        

         
    
    
}

