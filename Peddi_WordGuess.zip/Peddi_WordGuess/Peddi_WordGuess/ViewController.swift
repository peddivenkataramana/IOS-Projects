//
//  ViewController.swift
//  Peddi_WordGuess
//
//  Created by Peddi,Venkataramana on 3/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var gssbn: UIButton!
    
    @IBOutlet weak var plbtn: UIButton!
    
    var arr = [["SWIFT", "Programming Language"],
               ["DOG", "Animal"],
               ["CYCLE", "Two wheeler"],
               ["MACBOOK", "Apple device"],
               ["JAVA","OOPS"]]
    
    var lettersGuessed = ""
    var word = ""
    var count = 0
    var g = 0
    var t = 5
    var maxNumOfWrongGuesses = 10
    var a = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//         displayImag{e.image  = UIImage(named: "welcome")
        if(count != 5){
            hintLabel.text = "Hint: "+arr[count][1]
            word = arr[count][0]}
        userGuessLabel.text = ""
        updateUnderscores()
        wordsGuessedLabel.text! = "Total number of words guessed successfully: \(g)"
        wordsRemainingLabel.text = "Total number of words remaining in game: \(t)"
        totalWordsLabel.text = "Total number of words in game: \(5)"
        gssbn.isEnabled = false
        guessCountLabel.text = "You have Made \(a) Guessess"
        plbtn.isHidden = true
    }

    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        var letter = guessLetterField.text!
        
        lettersGuessed = lettersGuessed + letter
                 var revealedWord = ""
                for l in word{
                    if lettersGuessed.contains(l){
                        revealedWord += "\(l)"
                    }
                    else{
                        revealedWord += "_ "
                    }
                   
                }
        maxNumOfWrongGuesses = maxNumOfWrongGuesses - 1
        if(maxNumOfWrongGuesses == 0 )
        {
            gssbn.isEnabled = false
            guessCountLabel.text = "You have used all the available guesses, Please play again"
            plbtn.isHidden = false
        }else{
        a = a+1
        guessCountLabel.text = "You have Made \(a) Guessess"
        }
        userGuessLabel.text = revealedWord
        guessLetterField.text = ""
        
        if userGuessLabel.text!.contains("_") == false{
                   plbtn.isHidden = false;
                   gssbn.isEnabled = false;
            guessCountLabel.text = "Wow!You have Made \(a) guessess to \n guess the word!"
            g = g+1
            wordsGuessedLabel.text! = "Total number of words guessed successfully: \(g)"
            t = t-1
            wordsRemainingLabel.text = "Total number of words remaining in game: \(t)"
                }
               
            }
        
        
        
    
        
        
     
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        
        if userGuessLabel.text!.contains("_") == true{
            a = 0}
        else  {
           
            a = 0
            count = count + 1
            if(count == 5){
                a = 0
                g = 0
                t = 5
                viewDidLoad()
                count = 0
                statusLabel.text = "Congratulations, You are done, Please start over again"
                guessCountLabel.text = ""
                hintLabel.text = ""
               
                
            }else{
            hintLabel.text = "Hint: "+arr[count][1]
            word = arr[count][0]
            userGuessLabel.text = ""
            updateUnderscores()
            guessCountLabel.text = ""
            lettersGuessed = ""
            }
            
        }
       
        
    
    }
    func updateUnderscores(){
            for letter in word{
                userGuessLabel.text! += "_ "
            }}

   
    
    
    @IBAction func gsbtn(_ sender: Any) {
        gssbn.isEnabled = true
    }

}

