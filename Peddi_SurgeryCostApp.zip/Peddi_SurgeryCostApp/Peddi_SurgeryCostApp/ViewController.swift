//
//  ViewController.swift
//  Peddi_SurgeryCostApp
//
//  Created by Peddi,Venkataramana on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    
    @IBOutlet weak var b: UITextField!
    
    @IBOutlet weak var c: UITextField!
    
    @IBOutlet weak var dis: UILabel!
    
    @IBOutlet weak var im: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func cal(_ sender: Any) {
    
    
    var a = a.text!
    var b = b.text!
        var c  = Double(c.text!)
         
        if(b == "Heart"){
            
            var  total = "\((c!*(1+11.75))-500)"
            im.image = UIImage(named:"Heart")
            dis.text! = "\(a):Total cost for Heart surgey is $\(total)"
             
        }
        else if ( b == "Brain"){
            
          var  total = c!*(1+13.5)-750;
            im.image = UIImage(named:"Brain")
            dis.text! = "\(a): Total cost for Brain surgey is $\(total)"

        }
        
        else if ( b == "Knee replacement"){
            
          var  total = c!*(1+6.25)-350;
            dis.text! = "\(a): Total cost for Knee replacement surgey is $\(total)"
            im.image = UIImage(named:"Knee")
            
            
        }else{
            dis.text! = "Enter all the details"
        }
        
        
        
        
        
        
        
        
    }
    
    
    
}

