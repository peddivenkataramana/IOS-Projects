//
//  ResultviewcontrollerViewController.swift
//  DiscountAppMVC
//
//  Created by Peddi,Venkataramana on 3/30/23.
//

import UIKit

class ResultviewcontrollerViewController: UIViewController {
    
    
    
    @IBOutlet weak var a: UILabel!
    
    
    @IBOutlet weak var d: UILabel!
    
    @IBOutlet weak var pr: UILabel!
    
    var amt = ""
    var dis = ""
    var price = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        a.text = amt
        
        
        
        
    }
    

    

}
