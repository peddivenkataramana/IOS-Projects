//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Peddi,Venkataramana on 3/30/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    
    @IBOutlet weak var d: UITextField!
    
    var pricaf = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func cal(_ sender: Any) {
        // read the text and convert it to double
        var amt = Double(a.text!)
        print(amt!)
        var dis = Double(d.text!)
        print(dis!)
         pricaf = amt! - (amt!*dis!/100)
        print(pricaf)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition  = segue.identifier
        if(transition == "resultSegue"){
            ///set the destination
            var destination = segue.destination as! ResultviewcontrollerViewController
            destination.amt = a.text!
            destination.dis = d.text!
            destination.price = String(pricaf.text!)
        }
    }
    
}

