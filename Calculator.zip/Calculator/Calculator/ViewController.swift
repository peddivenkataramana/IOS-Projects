//
//  ViewController.swift
//  Calculator
//
//  Created by Peddi,Venkataramana on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var displayoutlet: UILabel!
    
    //Declare and initiaze to some default values .
    
    var operand1:Double = -1.1
    var _operator : Character = " "
    var operand2 : Double = -1.1
    
    
    
     
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn1(_ sender: Any) {
        displayoutlet.text = "1"
        if operand1 == -1.1 {
            operand1 = 1
        }
        else{
            operand2=1
        }
    }
    
    
    @IBAction func btn2(_ sender: Any) {
        displayoutlet.text = "2"
        if operand2 == -1.1{
            operand2 = 2
        }
        else {
            operand1 = 2
        }
    }
    
    @IBAction func btnmin(_ sender: Any) {
        
        displayoutlet.text = "+"
        if _operator == " "{
            _operator = "+"
        }
        
        
        
    }
    
    @IBAction func btneq(_ sender: Any) {
        displayoutlet.text = "="
        if(_operator == "+"){
            displayoutlet.text = displayoutlet.text!+"\(operand1+operand2)"
        }
    }
    
    @IBAction func btnplus(_ sender: Any) {
        displayoutlet.text = "-"
    }
    
    
    
}

