//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Peddi,Venkataramana on 3/30/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var uname: UITextField!
    
    @IBOutlet weak var age: UITextField!
    
    
    @IBOutlet weak var pet: UITextField!
    
 
  
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition  = segue.identifier
               if(transition == "resultSegue"){
                   ///set the destination
                   
                   var destination = segue.destination as! ResultviewcontrollerViewController
                   
                   destination.a =  String(uname.text!)
                 destination.b =  String(age.text!)
                   destination.c =  String(pet.text!)
                   
               }
        
        
        
        
    }
    
   
//
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        var transition  = segue.identifier
//        if(transition == "resultSegue"){
//            ///set the destination
//            var destination = segue.destination as! ResultviewcontrollerViewController
//            destination.amt = a.text!
//            destination.dis = d.text!
//            destination.price = String(pricaf.text)
//        }
//    }
    
}

