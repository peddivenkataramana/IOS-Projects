//
//  Resultview1ViewController.swift
//  DiscountAppMVC
//
//  Created by Peddi,Venkataramana on 4/3/23.
//

import UIKit

class Resultview1ViewController: UIViewController {

    @IBOutlet weak var petn: UILabel!
    
    @IBOutlet weak var discr: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    
    var a = ""
    
    var b = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        petn.text = "Pet Name:\(a)"
        discr.text = "About : \(b)"
        img.image = UIImage(named: "shs")
        
        
    }
    

   

}
