//
//  ResultviewcontrollerViewController.swift
//  DiscountAppMVC
//
//  Created by Peddi,Venkataramana on 3/30/23.
//

import UIKit

class ResultviewcontrollerViewController: UIViewController {
    
    
    @IBOutlet weak var name: UILabel!
    
    
    @IBOutlet weak var age: UILabel!
    
    @IBOutlet weak var pname: UILabel!
    
  
    @IBOutlet weak var about: UITextField!
    
    var a = ""
    var b = ""
    var c = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        name.text = "Name :\(a)"
        age.text = "Age :\(b)"
        pname.text = "Pet Name:\(c)"
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition  = segue.identifier
               if(transition == "resultsegue1"){
                   ///set the destination
                   
                   let destination = segue.destination as! Resultview1ViewController
                   
                   destination.a =  String(c)
                   destination.b = String(about.text!)

               }
        
        
        
        
    }

    

}
