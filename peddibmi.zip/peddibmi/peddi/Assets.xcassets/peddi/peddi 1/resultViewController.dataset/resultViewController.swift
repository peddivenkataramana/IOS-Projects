//
//  resultViewController.swift
//  peddi
//
//  Created by Kamani,Venkata Keerthi on 4/10/23.
//

import UIKit

class resultViewController: UIViewController {

    @IBOutlet weak var value: UILabel!
    var b = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        value.text = "BMI Value: \(b)"
        
        
        
    }
    
    @IBOutlet weak var img: UIImageView!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
