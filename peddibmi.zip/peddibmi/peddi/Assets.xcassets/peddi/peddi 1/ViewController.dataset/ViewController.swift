//
//  ViewController.swift
//  peddi
//
//  Created by Kamani,Venkata Keerthi on 4/10/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var hgt: UITextField!
    
    @IBOutlet weak var wght: UITextField!
    
    var bmi = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func cal(_ sender: Any) {
        
        var a = Double(hgt.text!)
        var b = Double(wght.text!)
       
        bmi = b!/((a!*0.3)*(a!*0.3))
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "result"{
            var destination = segue .destination as! resultViewController
            
            destination.b = round(bmi)
             
                        
 
            
        }
    }
    
    
    
    
    
}

