//
//  result1ViewController.swift
//  peddi
//
//  Created by Kamani,Venkata Keerthi on 4/11/23.
//

import UIKit

class result1ViewController: UIViewController {
    
    
    @IBOutlet weak var img: UIImageView!
    
    var ui = UIImage()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
                var width = img.frame.width
        
                       width += 20
        
                       var height = img.frame.height
        
                       height = height + 20
        
                       var x  =  img.frame.origin.x+40
        
        
                       var y = img.frame.origin.y+400
        
                       var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
                UIView.animate(withDuration: 1, delay: 1, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                    self.img.frame = largeFrame
                })
        
        img.image = ui
        
        
        
        
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
