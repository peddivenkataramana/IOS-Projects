//
//  resultViewController.swift
//  peddi
//
//  Created by Kamani,Venkata Keerthi on 4/10/23.
//

import UIKit

class resultViewController: UIViewController {
    
    @IBOutlet weak var value: UILabel!
    var b = 0.0
    
    
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        value.text = "BMI Value: \(b)"
        
        if(b<=18){
            
            img.image = UIImage(named: "uw")
        }
        else if((18...25).contains(b)){
            img.image = UIImage(named: "nw")
        }
        else if(b>=40) {
            img.image = UIImage(named: "ow")
        }
    }
    
    @IBAction func ani(_ sender: Any) {
      
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "result1"{
            var destination = segue .destination as! result1ViewController
            
            destination.ui = img.image!
            
            
            
            
            
        }
        
        
    }}
