//
//  ViewController.swift
//  DiscountApp
//
//  Created by Peddi,Venkataramana on 2/14/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amountOutlet: UITextField!
    
    
    
    @IBOutlet weak var discrateOutlet: UITextField!
    
    
    
    @IBOutlet weak var displayLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcdiscount(_ sender: Any) {
        //Read the input
        var a = (Double)(amountOutlet.text!)
        var b = (Double)(discrateOutlet.text!)
        var p = (a! - (a! * b!/100))
        displayLabel.text =  "Price after discount: $\(p)"
        
    }
    
}

