//
//  ViewController.swift
//  DisplayApp1
//
//  Created by Peddi,Venkataramana on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lb: UITextField!
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn(_ sender: Any) {
        
        let a = Int(lb.text!)
        
        if(a!<50 && a!>10){
            img.image=UIImage(named: "summer")
        }
        else if(a! < 0 )
        {
            img.image=UIImage(named: "snow")
            
        }else{
            img.image = UIImage(named: "spring")
        }
        
        
    }
    
}

