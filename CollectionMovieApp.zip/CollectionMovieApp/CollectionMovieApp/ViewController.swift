//
//  ViewController.swift
//  CollectionMovieApp
//
//  Created by Peddi,Venkataramana on 4/20/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movie.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MCollectionViewCell
        cell.assignMovie(with: movie[indexPath.row])
               
               return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           assignMovieDetails(index: indexPath)
       }
    func assignMovieDetails(index: IndexPath){
           ti.text = "Movie title: \(movie[index.row].title)"
       }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionview.dataSource = self
        collectionview.delegate = self
    }

    var movie = movies
    
    @IBOutlet weak var ti: UILabel!
    
    @IBOutlet weak var yr: UILabel!
    @IBOutlet weak var collectionview: UICollectionView!
    
    @IBOutlet weak var ra: UILabel!
    
    @IBOutlet weak var bx: UILabel!
   
}

