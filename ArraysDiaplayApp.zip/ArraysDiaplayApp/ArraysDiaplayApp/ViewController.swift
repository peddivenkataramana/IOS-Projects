//
//  ViewController.swift
//  ArraysDiaplayApp
//
//  Created by Peddi,Venkataramana on 3/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var crs: UILabel!
    
    @IBOutlet weak var cour: UILabel!
    
    
    @IBOutlet weak var sem: UILabel!
    
    @IBOutlet weak var nxtout: UIButton!
    
    
    @IBOutlet weak var prevout: UIButton!
    
    var imgnum = 0
    let c = [["img01","44555","Network Security","Fall 2022"],
            ["img02","44643","ios","Spring 2023"],
            ["img03","44344","Streaming Data","Summer 2024"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //load the frst image(image in the 0 th position)
        //load the course details
        img.image = UIImage(named: c[0][0])
        crs.text = "\(c[0][1])"
        cour.text="\(c[0][2])"
        sem.text="\(c[0][3])"
        // prev disabled
        prevout.isEnabled = false
        // next enabled
        nxtout.isEnabled = true
    }

    func updatecoursedetails(_ imgnum:Int){
        img.image = UIImage(named: c[imgnum][0])
        crs.text = c[imgnum][1]
        cour.text = c[imgnum][2]
        sem.text = c[imgnum][3]
    }
    
    
    @IBAction func nxt(_ sender: Any) {
        //increment img number
        imgnum += 1
        //update course details
        updatecoursedetails(imgnum)
        //prev must be enabled
        prevout.isEnabled = true
        //when we reach end of the array nxt btn is disabled
        if(imgnum == c.count-1){
            nxtout.isEnabled = false
        }
    }
    
    @IBAction func prev(_ sender: Any) {
        // decrement image number
        imgnum -= 1
        //update course details
        updatecoursedetails(imgnum)
        
        nxtout.isEnabled = true
        //reach the starting of the array disable prev btn
        if(imgnum == 0){
            prevout.isEnabled = false
            
        }
    }
    
    
    
    
    
    
}

