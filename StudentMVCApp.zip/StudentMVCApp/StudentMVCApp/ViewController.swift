//
//  ViewController.swift
//  StudentMVCApp
//
//  Created by Peddi,Venkataramana on 4/4/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var SID: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func det(_ sender: Any) {
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition  = segue.identifier
               if(transition == "resultSegue"){
                   ///set the destination
                   
                   var destination = segue.destination as! ResultviewcontrollerViewController
                   
                   destination.a =  String(uname.text!)
                 destination.b =  String(age.text!)
                   destination.c =  String(pet.text!)
                   
               }
        
        
    
    
    
    
    
    
}

