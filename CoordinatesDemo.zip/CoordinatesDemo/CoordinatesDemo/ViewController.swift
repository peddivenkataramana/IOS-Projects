//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Peddi,Venkataramana on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageviewoutlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //min x and miny
        
        let minX = imageviewoutlet.frame.minX;
        
        let minY = imageviewoutlet.frame.minY
        print("(\(minX),\(minY))")
        
        let maxX = imageviewoutlet.frame.maxX;
        
        let maxY = imageviewoutlet.frame.maxY
        print("(\(maxX),\(maxY))")
        
        let midX = imageviewoutlet.frame.midX;
        
        let midY = imageviewoutlet.frame.midY
        print("(\(midX),\(midY))")
        
        
        
        //move the locstion of the image view to the upper left corner.
        imageviewoutlet.frame.origin.x = 0
        imageviewoutlet.frame.origin.y = 0
        
        imageviewoutlet.frame.origin.x = 314
        imageviewoutlet.frame.origin.y = 0
        
        imageviewoutlet.frame.origin.x = 0
        imageviewoutlet.frame.origin.y = 796
        
        //bttm left
        imageviewoutlet.frame.origin.x = 314
        imageviewoutlet.frame.origin.y = 796
        
        //midpoint
        imageviewoutlet.frame.origin.x = 207 - 50
        imageviewoutlet.frame.origin.y = 398 - 50
        
        
        
    }


}

