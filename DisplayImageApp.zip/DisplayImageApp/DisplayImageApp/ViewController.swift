//
//  ViewController.swift
//  DisplayImageApp
//
//  Created by Peddi,Venkataramana on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayol: UILabel!
    @IBOutlet weak var imageol: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clickol(_ sender: Any) {
        imageol.image = UIImage(named: "download")
        displayol.text!="Cutest dog on earth."
    }
    
}

