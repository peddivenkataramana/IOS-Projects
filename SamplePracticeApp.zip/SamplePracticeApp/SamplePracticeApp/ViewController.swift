//
//  ViewController.swift
//  SamplePracticeApp
//
//  Created by Peddi,Venkataramana on 1/26/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var crs1outlet: UITextField!
    
    @IBOutlet weak var crs2outlet: UITextField!
    
    @IBOutlet weak var displayoutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitoutlet(_ sender: Any) {
    
  // Read course 1 name and store in a  varible
    var course1name = crs1outlet.text!
    
    var course2name = crs2outlet.text!
    
    
    
    
   // Read course 2 name and store in a variable
    
    //Perform String interpolation and assign to display label.(course 1 - course2).
    displayoutlet.text = "\(course1name) - \(course2name)"
    
    }}

